/**
 * Compiler phases.
 * 
 * @author bostjan.slivnik@fri.uni-lj.si
 */
package prev26lang.phase;
